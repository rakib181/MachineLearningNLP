In this part, we will write the code that detects emotion from the text.

In `coding_part.ipynb` each sentence in `emotion\_presence\_dataset\_q2.csv` is coded into one emotion: anger, fear, joy, sadness, surprise (or neutral). It is a comparison of three feature methods (word frequency, hash values and Word2Vec embeddings) and two models (Decision Tree and Logistic Regression).

## Requirements

* Python 3.9 or later
* Data: Iris, Wine, or any other dataset you prefer.
* Tools: JupyterLab, Jupyter Notebooks, and Google Colab

The first cell of the notebook sets up the packages. It also downloads the necessary NLTK data files, which include the wordnet, punkt\_tab and stopwords; an internet connection is needed.

## How to run

1. Start up Jupyter Notebooks and open `coding\_part.ipynb` with it, or upload it to Google Colab.
2. Run all cells from top to bottom:

   * Jupyter: Run All Cells
   * Colab: Run all → Runtime

By default the dataset is loaded from GitHub. If you wish to use a local copy, place `emotion\_presence\_dataset\_q2.csv` in the same folder as the notebook. In Step 4, then, comment out the line `pd.read\_csv(link)` and uncomment the line `df = pd.read\_csv("emotion\_presence\_dataset\_q2.csv")`.

## Pipeline

1. Shuffle the data, then split it 70% train, 15% dev, 15% test.
2. Process the text: tokenise, lemmatise, lower case, remove stopwords and punctuation.
3. Implement three types of features: word frequency, hash values and Word2Vec.
4. For each feature method:

   * Train the Decision Tree and Logistic Regression using the dev set, and obtain their best macro-F1 scores.
Retrain them on train + dev.
   * Test on the test set.

## Output

A classification report (precision, recall, F1 per emotion and macro averages) and accuracy are printed for each experiment. Saves the test predictions (id, text, gold, pred) to:

|Features|Decision Tree|Logistic Regression|
|-|-|-|
|Word frequency|`test\_predictions\_decisionTree1.csv`|`test\_predictions\_logictic1.csv`|
|Hash values|`test\_predictions\_decisionTree2.csv`|`test\_predictions\_logictic2.csv`|
|Word2Vec|`test\_predictions\_decisionTree3.csv`|`test\_predictions\_logictic3.csv`|

## Note

Results change slightly between runs, for three reasons:

* There is no set shuffle seed.
The hash value of strings in Python is not fixed and varies between sessions.
Randomisation is done in Word2Vec training.

